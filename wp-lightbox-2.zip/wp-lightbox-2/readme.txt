=== WP Lightbox 2 ===
Contributors: Pankaj Jha
Plugin Site: http://onlinewebapplication.com/
Tags: lightbox, WP Lightbox, AJAX, image, photo, picture, JQuery WP Image Plugin
Requires at least: 1.5
Tested up to: 3.2.1
Stable tag: 3.0.0

This plugin used to add the lightbox (overlay) effect to the current page images on your WordPress blog.
== Description ==
This plugin used to add the lightbox (overlay) effect to the current page images on your WordPress blog.
Used to overlay images on the current page. Extension of Lightbox 2 which features 'auto-lightboxing' of image links, courtesy of Michael Tyson and Lightbox2.

Just install and sit back. This plugin enable image overlay lighbox effect for all the post images in your wordpress plugin. No configuration required.

[Plugin Home Page](http://onlinewebapplication.com/2011/11/wp-lightbox-2.html)
== Installation ==

To do a new installation of the plugin, please follow these steps

1. Download the zipped plugin file to your local machine.
2. Unzip the file.
3. Upload the `WP-lightbox-2` folder to the `/wp-content/plugins/` directory.
4. Activate the plugin through the 'Plugins' menu in WordPress.
5. Optionally, go to the Options page and select a new Lightbox colour scheme.


== Frequently Asked Questions ==

You can Check Screen Shots on my website :<br />
[WP Lightbox 2](http://onlinewebapplication.com/2011/11/wp-lightbox-2.html)<br />

== Screenshots ==
You can Check Screen Shots on my website :<br />
[WP Lightbox 2](http://onlinewebapplication.com/2011/11/wp-lightbox-2.html)<br />